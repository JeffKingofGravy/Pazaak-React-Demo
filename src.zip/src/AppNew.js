import React, { PureComponent, Component } from 'react';
import autobind from 'autobind-decorator';
import logo from './logo.svg';
import trash from './trash.png';
import './App.css';
import data from './data.json';
// import data from './savedData.json';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            newList: [],
            value: ''
        };
    }

    addListItem = (i) => {
        if (this.state.value === '') {
            return;
        }

        const {newList} = this.state;
        const item = Item(Date.now(), this.state.value, false);
        newList.push(item);
        this.setState({newList});
        this.setState({value: ''});
    }

    valueChanged = (evt) => {
        this.setState({value: evt.target.value});
    }

    checkKey = (evt) => {
        if (evt.key === 'Enter')
        {
            this.addListItem();
        }
    }

    deleteItem = (id) => {
        const {newList} = this.state;
        let newArray = newList.filter(e => e.id !== id);
        console.log(newArray);
        this.setState({newList: newArray});
    }

    remove = (array, element) => {
        return array.filter(e => e !== element);
    }

    render = () => {
        const {newList} = this.state;
        return (
            <div className="App">
                <header className="Head">

                </header>
                <div className="Main">
                    <div className="Input">
                        <input value={this.state.value} onChange={this.valueChanged} onKeyDown={this.checkKey}/>
                        <input type="submit" value="Submit" onClick={this.addListItem}/>
                    </div>
                    <hr/>
                    <div className="dataLists" >
                        <div id="newList">
                            {newList.map((i, j) => <ListItem item={i} key={j} callback={this.deleteItem}/>)}
                        </div>
                    </div>

                </div>
            </div>
        );
    }
}

class ListItem extends Component {
    constructor(props) {
        super(props);
        this.state = {
            item: {
                text: this.props.item.text,
                id: this.props.item.id,
                completed: this.props.item.completed
            }
        };
    }

    removeItem = (evt) => {
        this.props.callback(this.state.item.id);
    }

    setComplete = (evt) => {
        const {item} = this.state;
        item.completed = !item.completed;
        this.setState({item});
    }

    render = () => {
        const {item} = this.state;
        const style = item.completed === true ? {textDecorationLine: 'line-through', textDecorationStyle: 'solid'} : {};
        return (
            <li>
                <span className="itemText" onClick={this.setComplete} style={style}>
                    {item.text}
                </span>
                <span className="trashImg" onClick={() => this.removeItem(item.id)}>
                    <img src={trash} alt="trash" />
                </span>
            </li>
        );
    }
}

const Item = (i, t, c) => ({
    id: i,
    text: t,
    completed: c
});

export default App;
