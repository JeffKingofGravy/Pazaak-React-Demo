import React, { PureComponent, Component } from 'react';
import logo from './logo.svg';
import trash from './trash.png';
import './App.css';
import data from './data.json';
// import data from './savedData.json';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            newList: this.props.list,
            savedList: data,
            value: ''
        };
    }

    addListItem = (i) => {
        if (this.state.value === '') {
            return;
        }

        const {newList} = this.state;
        let item = Item(this.state.value);
        newList.push(item.text);
        this.setState({newList});
        this.setState({value: ''});
    }

    valueChanged = (evt) => {
        this.setState({value: evt.target.value});
    }

    checkKey = (evt) => {
        if (evt.key === 'Enter')
        {
            this.addListItem();

        }
    }

    removeNewItem = (text) => {
        let {newList} = this.state;
        let index = newList.indexOf(text);
        console.log(index);
        newList.splice(index, 1);
        console.log(newList);
        this.setState({newList});
    }

    removeOldItem = (id) => {
        console.log(id);
    }

    saveSingleToStorage = () => {

    }

    saveListToStorage = () => {

    }

    render = () => {
        const {newList} = this.state;
        const {savedList} = this.state;
        return (
            <div className="App">
                <header className="Head">

                </header>
                <div className="Main">
                    <div className="Input">
                        <input value={this.state.value} onChange={this.valueChanged} onKeyDown={this.checkKey}/>
                        <input type="submit" value="Submit" onClick={this.addListItem}/>
                    </div>
                    <hr/>
                    <div className="dataLists" >
                        <div id="newList">
                            {newList.map((i, j) => <ListItem text={i} id={j} key={j} callback={this.removeNewItem}/>)}
                        </div>
                        <br/>
                        <div id="oldList" >
                            {savedList.map((i, j) => <ListItem text={i} id={j} key={j} callback={this.removeOldItem}/>)}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

class ListItem extends PureComponent {
    constructor(props) {
            super(props);
            this.state = {
                text: this.props.text,
                id: this.props.id
            };
    }

    removeItem = (evt) => {
        this.props.callback(this.state.text);
    }

    render = () => {
        return (
            <li>
                <span className="itemText">
                    {this.state.text}
                </span>
                <span className="itemRemoveSpan">
                    <button className="removeButton" onClick={this.removeItem}>
                        Remove
                    </button>
                </span>
            </li>
        );
    }
}

const Item = (t) => ({
    text: t
});

export default App;
